module.exports = {
  DB_URI:
    "mongodb+srv://yilmaz:programci2707@cluster0-5yjpf.mongodb.net/myPortfolio?retryWrites=true&w=majority",
};
