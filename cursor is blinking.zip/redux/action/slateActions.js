export const setEditor = (value) => ({ type: "SET_VALUE", payload: value });
