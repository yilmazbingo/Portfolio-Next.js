// import { defaultValue } from "../../components/slate-editor/dafaultValue";

export default (state = {}, action) => {
  switch (action.type) {
    //   case "SET_VALUE":
    //     return [...state, action.payload];
    default:
      return state;
  }
};
