import React, { useState } from "react";
import { addDays } from "date-fns";
import DatePicker from "react-datepicker";
import { FormGroup, Label, Button } from "reactstrap";

import "react-datepicker/dist/react-datepicker.css";

const FormDate = (props) => {
  const [startDate, setStartDate] = useState(new Date());

  //passing field from formik to handle change will not work. because we need to pass event or path
  //but here we are just passing plain date
  //   const handleChange = (date) => {
  //     // debugger;
  //     const { setFieldValue, setFieldTouched } = props.form;
  //     const { name } = props.field;
  //     setStartDate(date);
  //     setFieldValue(name, date, true);
  //     setFieldTouched(name, true, true);
  //   };

  const { name } = props;
  const nameUpperCase = name.toUpperCase();
  return (
    <FormGroup>
      <Label className="label">{nameUpperCase}</Label>
      <div className="input-group">
        <DatePicker
          selected={startDate}
          onChange={(date) => setStartDate(date)}
          peekNextMonth
          showMonthDropdown
          showYearDropdown
          maxDate={addDays(new Date(), 0)}
          dropdownMode="select"
        />
      </div>
    </FormGroup>
  );
};

export default FormDate;
