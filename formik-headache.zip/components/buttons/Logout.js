import React from "react";
import { Button } from "reactstrap";

const Logout = () => {
  return <Button color="success">Logout</Button>;
};

export default Logout;
