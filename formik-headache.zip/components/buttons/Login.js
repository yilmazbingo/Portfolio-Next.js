import React from "react";
import { Button } from "reactstrap";

const Login = () => {
  return <Button color="success">Login</Button>;
};

export default Login;
